notes-template
==============

A simple template for notes taken in courses at the University of Waterloo
